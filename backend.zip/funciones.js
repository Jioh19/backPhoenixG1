const fs = require('fs');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

//AUTH
async function register(dataRegistro) {
	try {
		const usuarios = await JSON.parse(fs.readFileSync('./DB/users.json'));
		let id;
		if (usuarios.length === 0) {
			id = 0;
		} else {
			id = Number(usuarios[usuarios.length - 1].id) + 1;
		}
		const usuario = { ...dataRegistro, id: id };

		const encryptedPassword = await bcrypt.hash(usuario.password, 10);
		usuario.password = encryptedPassword;
		usuarios.push(usuario);
		// Creación del Token
		const token = jwt.sign(
			{
				id: usuario.id,
				email: usuario.email,
			},
			'Clave secreta!!!',
			{
				expiresIn: '30m',
			}
		);
		// Token Generado
		console.log('\nToken Generado: ' + token);

		fs.writeFileSync('./DB/users.json', JSON.stringify(usuarios, null, 2));
		return usuario;
	} catch (error) {
		console.log(error.message);
		return;
	}
}
async function login(username, password) {
	try {
		const usuarios = await JSON.parse(fs.readFileSync('./DB/users.json'));
		const usuario = await usuarios.find((user) => user.username == username);
		if (usuario == undefined) {
			return {
				code: 401,
				message: 'Nombre de Usuario o Password incorrectos',
			};
		}
		const check = await bcrypt.compare(password, usuario.password);
		if (!check) {
			return {
				code: 401,
				message: 'Nombre de Usuario o Password incorrectos',
			};
		}
		const token = jwt.sign(
			{
				id: usuario.id,
				email: usuario.email,
			},
			'Clave secreta!!!',
			{
				expiresIn: '30m',
			}
		);
		// Impresión por el terminal del Token generado para el usuario
		console.log('Usuario: ' + usuario.email + '\nToken: ' + token);
		return {
			code: 200,
			token: token,
			message: 'Usuario autenticado',
		};
	} catch (error) {
		console.log(error.message);
		return;
	}
}

//PRODUCTOS
async function crearProducto(product) {}
async function obtenerDetalleProducto(id) {}
async function obtenerProductos() {}
async function modificarProducto(id) {}
async function borrarProducto(id) {}

//USUARIO
async function obtenerUsuarios() {
	try {
		const usuarios = await JSON.parse(fs.readFileSync('./DB/users.json'));
		return usuarios;
	} catch (error) {
		console.log(error.message);
		return;
	}
}

async function obtenerUsuario(id) {
	try {
		const usuarios = await JSON.parse(fs.readFileSync('./DB/users.json'));
		const usuario = usuarios.find((user) => user.id == id);
		return usuario;
	} catch (error) {
		console.log(error.message);
		return;
	}
}
async function modificarUsuario(id, user) {
	try {
		const usuarios = await JSON.parse(fs.readFileSync('./DB/users.json'));
		const index = usuarios.findIndex((usuario) => usuario.id == id);
		console.log(id, user, index);
		user.id = usuarios[index].id;
		user.email ||= usuarios[index].email;
		user.username ||= usuarios[index].username;
		user.firstName ||= usuarios[index].firstName;
		user.lastName ||= usuarios[index].lastName;
		user.city ||= usuarios[index].city;
		user.street ||= usuarios[index].street;
		user.number ||= usuarios[index].number;
		user.zipcode ||= usuarios[index].zipcode;
		user.password ||= usuarios[index].password;
		usuarios[index] = user;

		fs.writeFileSync('./DB/users.json', JSON.stringify(usuarios, null, 2));
		return user;
	} catch (error) {
		console.log(error.message);
		return;
	}
}
async function eliminarUsuario(id) {
	try {
		let usuarios = await JSON.parse(fs.readFileSync('./DB/users.json'));
		const usuario = usuarios.find((usuario) => usuario.id == id);
		usuarios = usuarios.filter((usuario) => usuario.id != id);

		fs.writeFileSync('./DB/users.json', JSON.stringify(usuarios, null, 2));
		return usuario;
	} catch (error) {
		console.log(error.message);
		return;
	}
}

//USUARIO - CARRITO
async function obtenerCarrito(idUsuario) {
	try {
		const carritos = await JSON.parse(fs.readFileSync('./DB/carts.json'));
		let carrito = await carritos.find((cart) => cart.id == idUsuario);
		if (carrito == undefined) {
			carrito = {
				id: idUsuario,
				productos: [],
			};
			carritos.push(carrito);
		}
		fs.writeFileSync('./DB/carts.json', JSON.stringify(carritos, null, 2));
		return carrito;
	} catch (error) {
		console.log(error.message);
		return;
	}
}
async function agregarProductoAlCarrito(idUsuario, producto) {
	try {
		const carritos = await JSON.parse(fs.readFileSync('./DB/carts.json'));
		const carrito = await carritos.find((cart) => cart.id == idUsuario);
		carrito.productos.push(producto);
		fs.writeFileSync('./DB/carts.json', JSON.stringify(carritos, null, 2));
		return carrito;
	} catch (error) {
		console.log(error.message);
		return;
	}
}

async function eliminarProductoAlCarrito(idUsuario, idProducto) {
	try {
		const carritos = await JSON.parse(fs.readFileSync('./DB/carts.json'));
		const carrito = await carritos.find((cart) => cart.id == idUsuario);
		carrito.productos = carrito.productos.filter(
			(prod) => prod.id == idProducto
		);
		fs.writeFileSync('./DB/carts.json', JSON.stringify(carritos, null, 2));
		return carrito;
	} catch (error) {
		console.log(error.message);
		return;
	}
}
async function modificarProductoAlCarrito(idUsuario, idProducto) {}

module.exports = {
	register,
	login,
	crearProducto,
	obtenerDetalleProducto,
	obtenerProductos,
	modificarProducto,
	borrarProducto,
	obtenerCarrito,
	agregarProductoAlCarrito,
	eliminarProductoAlCarrito,
	modificarProductoAlCarrito,
	obtenerUsuarios,
	obtenerUsuario,
	modificarUsuario,
	eliminarUsuario,
};
